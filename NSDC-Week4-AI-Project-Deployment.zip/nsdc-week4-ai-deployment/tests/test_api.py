from src.app import app

def test_health_endpoint():
    r = app.test_client().get("/health")
    assert r.status_code in (200, 503)
    assert r.json["status"] == "ok"

def test_missing_json_body_is_handled():
    r = app.test_client().post("/predict", json={})
    assert r.status_code in (400, 503)

def test_non_json_body_is_handled():
    r = app.test_client().post("/predict", data="bad", content_type="text/plain")
    assert r.status_code in (400, 503)
