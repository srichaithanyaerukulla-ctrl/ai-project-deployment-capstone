import statsmodels.api as sm

FEATURES = ["LOWINC", "PERASIAN", "PERBLACK", "PERHISP", "PERMINTE",
            "AVYRSEXP", "AVSALK", "PERSPENK", "PTRATIO", "PCTAF"]

def load_dataset():
    df = sm.datasets.star98.load_pandas().data.copy().drop_duplicates().reset_index(drop=True)
    denom = df["NABOVE"] + df["NBELOW"]
    if (denom <= 0).any():
        raise ValueError("Non-positive denominator for success-rate calculation")
    df["SUCCESS_RATE"] = df["NABOVE"] / denom
    return df

def build_xy(df):
    X = df[FEATURES].copy()
    threshold = float(df["SUCCESS_RATE"].median())
    y = (df["SUCCESS_RATE"] >= threshold).astype(int)
    return X, y, threshold
