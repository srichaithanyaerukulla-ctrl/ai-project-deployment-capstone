from pathlib import Path
import sys
ROOT_FOR_IMPORT = Path(__file__).resolve().parents[1]
if str(ROOT_FOR_IMPORT) not in sys.path:
    sys.path.insert(0, str(ROOT_FOR_IMPORT))
import joblib
import numpy as np
from flask import Flask, jsonify, request

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT/"models/educational_success_pipeline.joblib"
app = Flask(__name__)

@app.get("/health")
def health():
    exists = MODEL_PATH.exists()
    return jsonify({"status":"ok", "model_loaded":exists}), (200 if exists else 503)

@app.post("/predict")
def predict():
    if not MODEL_PATH.exists():
        return jsonify({"error":"Model not found. Run `python src/train.py` first."}), 503
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error":"Request body must be a JSON object."}), 400
    artifact = joblib.load(MODEL_PATH)
    features = artifact["features"]
    missing = [f for f in features if f not in payload]
    if missing:
        return jsonify({"error":"Missing required features.", "missing_features":missing}), 400
    try:
        values = [float(payload[f]) for f in features]
    except (TypeError, ValueError):
        return jsonify({"error":"All feature values must be numeric."}), 400
    if not np.isfinite(values).all():
        return jsonify({"error":"Feature values must be finite."}), 400
    pred = int(artifact["pipeline"].predict([dict(zip(features, values))])[0])
    prob = float(artifact["pipeline"].predict_proba([dict(zip(features, values))])[0,1])
    return jsonify({"prediction":pred,
        "predicted_label":"higher_success_rate_class" if pred else "lower_success_rate_class",
        "probability_higher_success_rate_class":round(prob,6),
        "note":"Educational demonstration only; not for consequential decisions."})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
