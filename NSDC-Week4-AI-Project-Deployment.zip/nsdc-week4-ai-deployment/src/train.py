import json
from pathlib import Path
import sys
ROOT_FOR_IMPORT = Path(__file__).resolve().parents[1]
if str(ROOT_FOR_IMPORT) not in sys.path:
    sys.path.insert(0, str(ROOT_FOR_IMPORT))
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, ConfusionMatrixDisplay, RocCurveDisplay)
from src.model_utils import load_dataset, build_xy, FEATURES

ROOT = Path(__file__).resolve().parents[1]
def main():
    (ROOT/"models").mkdir(exist_ok=True); (ROOT/"outputs").mkdir(exist_ok=True)
    df = load_dataset()
    X, y, threshold = build_xy(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y)
    pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=42))
    ])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test); prob = pipe.predict_proba(X_test)[:, 1]
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="f1")
    metrics = {
        "dataset": "STAR98 Educational Dataset (statsmodels)",
        "rows": int(len(df)), "features": FEATURES, "target_threshold": threshold,
        "target_definition": "SUCCESS_RATE >= median SUCCESS_RATE",
        "train_rows": int(len(X_train)), "test_rows": int(len(X_test)),
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision": float(precision_score(y_test, pred, zero_division=0)),
        "recall": float(recall_score(y_test, pred, zero_division=0)),
        "f1": float(f1_score(y_test, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, prob)),
        "train_5fold_cv_f1_mean": float(cv_scores.mean()),
        "train_5fold_cv_f1_std": float(cv_scores.std()),
        "cv_f1_scores": [float(x) for x in cv_scores]
    }
    joblib.dump({"pipeline": pipe, "features": FEATURES, "target_threshold": threshold},
                ROOT/"models/educational_success_pipeline.joblib")
    (ROOT/"outputs/evaluation_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    ConfusionMatrixDisplay.from_predictions(y_test, pred)
    plt.title("Week 4 — Confusion Matrix"); plt.tight_layout()
    plt.savefig(ROOT/"outputs/confusion_matrix.png", dpi=160); plt.close()
    RocCurveDisplay.from_predictions(y_test, prob)
    plt.title("Week 4 — ROC Curve"); plt.tight_layout()
    plt.savefig(ROOT/"outputs/roc_curve.png", dpi=160); plt.close()
    plt.figure(); plt.plot(range(1, 6), cv_scores, marker="o")
    plt.axhline(cv_scores.mean(), linestyle="--", label=f"Mean F1={cv_scores.mean():.3f}")
    plt.xlabel("CV fold"); plt.ylabel("F1-score"); plt.title("Training-only 5-fold CV")
    plt.legend(); plt.tight_layout(); plt.savefig(ROOT/"outputs/cross_validation_scores.png", dpi=160); plt.close()
    print(json.dumps({k: metrics[k] for k in ["accuracy","precision","recall","f1","roc_auc","train_5fold_cv_f1_mean"]}, indent=2))
if __name__ == "__main__":
    main()
