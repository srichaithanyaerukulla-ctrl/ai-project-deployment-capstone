# Validation Checklist

- [ ] Install requirements
- [ ] Run `python src/train.py`
- [ ] Verify model artifact and metrics JSON exist
- [ ] Verify three plot files exist
- [ ] Run `python -m pytest -q`
- [ ] Start Flask and test `GET /health`
- [ ] Test valid and invalid `POST /predict`
- [ ] For public deployment, host the service and verify the live URL

Local tests do not establish that the application is publicly deployed.
